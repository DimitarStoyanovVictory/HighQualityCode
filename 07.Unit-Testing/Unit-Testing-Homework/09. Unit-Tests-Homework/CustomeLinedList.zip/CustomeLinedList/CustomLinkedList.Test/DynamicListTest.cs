﻿using Xunit;

namespace CustomLinkedList.Test
{
    public class DynamicListTest
    {

    }
}
